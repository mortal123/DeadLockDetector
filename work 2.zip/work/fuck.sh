LD_PRELOAD=./hook.so ./source
