#include <stdio.h>


int main() {
	FILE * fout = fopen("report", "w");
	int i;	
	for (i = 1; i <= 100; i++) {
		puts("weng da ye");
	}
	return 0;
}
